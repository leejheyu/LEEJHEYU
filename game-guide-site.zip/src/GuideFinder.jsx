import React, { useState } from "react";

export default function GuideFinder() {
  const [query, setQuery] = useState("");
  const [selectedSites, setSelectedSites] = useState([
    "gamefaqs",
    "gamespot",
    "ign",
    "gamewith",
    "game8"
  ]);

  const SITES = {
    gamefaqs: { name:"GameFAQs", buildSearch:(q)=>`https://duckduckgo.com/?q=site:gamefaqs.com+${encodeURIComponent(q)}` },
    gamespot: { name:"GameSpot", buildSearch:(q)=>`https://duckduckgo.com/?q=site:gamespot.com+${encodeURIComponent(q)}` },
    ign: { name:"IGN", buildSearch:(q)=>`https://duckduckgo.com/?q=site:ign.com+${encodeURIComponent(q)}` },
    steam: { name:"Steam 指南", buildSearch:(q)=>`https://duckduckgo.com/?q=site:steamcommunity.com+${encodeURIComponent(q)}+guide` },
    reddit: { name:"Reddit", buildSearch:(q)=>`https://duckduckgo.com/?q=site:reddit.com+${encodeURIComponent(q)}` },
    youtube: { name:"YouTube", buildSearch:(q)=>`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}+walkthrough` },
    gamewith: { name:"GameWith 攻略", buildSearch:(q)=>`https://duckduckgo.com/?q=site:gamewith.jp+${encodeURIComponent(q)}` },
    game8: { name:"Game8 攻略", buildSearch:(q)=>`https://duckduckgo.com/?q=site:game8.jp+${encodeURIComponent(q)}` }
  };

  function toggleSite(k){
    setSelectedSites(prev => prev.includes(k) ? prev.filter(x=>x!==k) : [...prev, k]);
  }

  function openAll(){
    if(!query.trim()) return;
    selectedSites.forEach(k=>{
      window.open(SITES[k].buildSearch(query.trim()), "_blank");
    });
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-3">遊戲攻略搜尋器</h1>
      <input className="p-2 border rounded w-full"
        placeholder="輸入遊戲名稱"
        value={query}
        onChange={e=>setQuery(e.target.value)}
      />
      <div className="mt-4 flex flex-wrap gap-2">
        {Object.entries(SITES).map(([k, info])=>(
          <button key={k}
            onClick={()=>toggleSite(k)}
            className={`px-3 py-1 rounded border ${selectedSites.includes(k) ? 'bg-green-200' : 'bg-white'}`}>
            {info.name}
          </button>
        ))}
      </div>
      <button onClick={openAll}
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">
        開啟所有搜尋
      </button>
    </div>
  );
}
